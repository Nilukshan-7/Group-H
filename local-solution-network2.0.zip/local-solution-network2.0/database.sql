USE local_solution;

-- Users table (all roles)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(255),
    role ENUM('user','provider','validator','admin'),
    status ENUM('active','blocked') DEFAULT 'active'
);

-- Problems table
CREATE TABLE problems (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(200),
    description TEXT,
    status ENUM('pending','approved','rejected','solved') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Solutions table
CREATE TABLE solutions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    problem_id INT,
    provider_id INT,
    solution TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
