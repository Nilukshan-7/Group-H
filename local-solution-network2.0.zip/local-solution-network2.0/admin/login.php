<?php
session_start();
include 'config/db.php';

if (isset($_POST['login'])) {

    $email = trim($_POST['email']);
    $password = md5(trim($_POST['password']));

    $query = "SELECT * FROM users 
              WHERE email='$email' 
              AND password='$password' 
              AND status='active'";

    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {

        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] == 'admin') header("Location: admin/dashboard.php");
        if ($user['role'] == 'user') header("Location: user/dashboard.php");
        if ($user['role'] == 'provider') header("Location: provider/dashboard.php");
        if ($user['role'] == 'validator') header("Location: validator/dashboard.php");

        exit();

    } else {
        echo "Invalid Login";
    }
}
?>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<form method="post">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="password" placeholder="Password">
    <button name="login">Login</button>
</form>
</html>
