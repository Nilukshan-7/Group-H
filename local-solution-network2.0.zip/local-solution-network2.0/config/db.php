<?php
$conn = mysqli_connect("localhost", "root", "", "local_solution");

if (!$conn) {
    die("Database connection failed");
}
?>
